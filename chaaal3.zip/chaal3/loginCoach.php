<?php
session_start();
$nom=$_SESSION['Nom'];
$prenom=$_SESSION['Prenom'];
$ID_Coach=$_SESSION['ID_Coach'];


$con=mysqli_connect("localhost", "root", "", "omnes");

$s1="SELECT * from coach where ID_Coach='$ID_Coach'";
$result1 = mysqli_query($con, $s1);

    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>"."ID_Coach"."</th>";
    echo "<th>"."Nom"."</th>";
    echo "<th>"."Prenom"."</th>";
    echo "<th>"."Email"."</th>";
    echo "<th>"."MDP"."</th>";
    echo "<th>"."Phone"."</th>";
    echo "<th>"."Email"."</th>";
    while ($row1 = mysqli_fetch_array($result1)) {
        echo "<tr>";
        echo "<td>".$row1["ID_Coach"]."</td>";
        echo "<td>".$row1["Nom"]."</td>";
        echo "<td>".$row1["Prenom"]."</td>";
        echo "<td>".$row1["Email"]."</td>";
        echo "<td>".$row1["MDP"]."</td>";
        echo "<td>".$row1["Phone"]."</td>";
        echo "<td>".$row1["Email"]."</td>";
        echo "</tr>";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .disconnect button{
               padding: 10px 25px;
               border: 2px solid #DA361B;
               border-radius: 5px;
               color: #000;
               cursor: pointer;
               background: transparent;
               margin-left : 1100px;
        }
        .disconnect button:hover{
            background-color: #DA361B;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="top" style="background-image: none!important;background-color: orange;height: 60vh;">
        <!-- header section starting here ========================== -->
        <div class="header">
          <div class="row">
            <div class="left">
              <h1>GetInShape</h1>
            </div>
            <div class="right">
              <a href="indexCoach.php">Home</a>
              <a href="#" onclick="showSearchHandler()">Browse</a>
              <a href="index.php#browseAll">Browse All</a>
              <a href="">My Account</a>
              <a href="appointment.php">Appointments</a>
              <a href="servicess.php">Services</a>
              <div class="menu" onclick="showMobileMenuHandler()">
                <p>Menu</p>
                <img src="assets/white-menu-icon-4.jpg" alt="" />
              </div>
            </div>
          </div>
          
        </div>
  
        <!-- header section end here =============================== -->
  
  
        <!-- search section start here ============== -->
         <div class="search" id="search">
          <span onclick="hideSearchHandler()">x</span>
            <form action="#">
                <input type="text" placeholder="Search here...">
                <button>Search</button>
            </form>
         </div>
        <!-- mobile menu section start here =========================== -->
        <div class="mobile" id="menuBack" onclick="hideMobileMenuHandler()">
          <div class="menu" id="menu">
            <a href="index.php">Home</a>
            <a href="#">Browse</a>
            <a href="#browseAll">Browse All</a>
              <a href="login.php">My Account</a>
              <a href="appointment.php">Appointments</a>
              <a href="servicess.php">Services</a>
          </div>
        </div>
        <!-- mobile menu section end here =========================== -->

        <!-- main content section start here, hero section ==================== -->
        <div class="disconnect">
                <a href="pages/login.html"><button type="button" name="disconnect">Disconnect</button></a>
                
                </div>
        <div class="main-section">
          
          <div class="row">
            <h1><?php echo htmlspecialchars($nom);echo " ";echo htmlspecialchars($prenom) ?></h1>
            <h2>Your informations<h2>
          </div>

        </div>
        
        <!-- main content section end here, hero section ==================== -->
      </div>
     
    </div>
    <script src="js/app.js"></script>
</body>
</html>

<?php
  $con=mysqli_connect("localhost", "root", "", "omnes");
  $s="SELECT * from reservation where ID_Coach='$ID_Coach'";
  $result1 = mysqli_query($con, $s);
  echo "<table border='1'>";
    echo "<tr>";
    echo "<th>"."date"."</th>";
    echo "<th>"."heure"."</th>";
    echo "<th>"."ID_Coach"."</th>";
  while ($row1 = mysqli_fetch_array($result1)) {
    echo "<tr>";
    echo "<td>".$row1["date"]."</td>";
    echo "<td>".$row1["heure"]."</td>";
    $ID_Client=$row1['ID_Client'];
    echo "<td>".$row1["ID_Coach"]."</td>";
    echo "</tr>";
}
echo "<table border='1'>";
    echo "<tr>";
    echo "<th>"."Nom"."</th>";
    echo "<th>"."Prenom"."</th>";
  $s="SELECT * from client where ID_Client='$ID_Client'";
  $result1 = mysqli_query($con, $s);
  while ($row1 = mysqli_fetch_array($result1)) {
  echo "<tr>";
  echo "<td>".$row1["Nom"]."</td>";
  echo "<td>".$row1["Prenom"]."</td>";
  echo "</tr>";
  }

?>


