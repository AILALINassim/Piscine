<?php
session_start();
$nom1=$_SESSION['Nom'];
$prenom1=$_SESSION['Prenom'];
$ID_Client1=$_SESSION['ID_Client'];

$con=mysqli_connect("localhost", "root", "", "omnes");
    $s1="SELECT * from coach";
    $result1 = mysqli_query($con, $s1); 
        while ($row1 = mysqli_fetch_array($result1)) {
            $nom[]=$row1["Nom"];
            $prenom[]=$row1["Prenom"];
            $activite[]=$row1["Activite"];
            $phone[]=$row1["Phone"];
            $email[]=$row1["Email"];  
            $image[]=$row1["image_url"];
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="top" style="background-image: none!important;background-color: orange;height: 60vh;">
        <!-- header section starting here ========================== -->
        <div class="header">
          <div class="row">
            <div class="left">
              <h1>LOGO</h1>
            </div>
            <div class="right">
              <a href="index.php">Home</a>
              <a href="#" onclick="showSearchHandler()">Browse</a>
              <a href="index.php#browseAll">Browse All</a>
              <a href="login.php">My Account</a>
              <a href="">Appointments</a>
              <a href="servicess.php">Services</a>
              <div class="menu" onclick="showMobileMenuHandler()">
                <p>Menu</p>
                <img src="assets/white-menu-icon-4.jpg" alt="" />
              </div>
            </div>
          </div>
        </div>
  
        <!-- header section end here =============================== -->
  
  
        <!-- search section start here ============== -->
         <div class="search" id="search">
          <span onclick="hideSearchHandler()">x</span>
            <form action="#">
                <input type="text" placeholder="Search here...">
                <button>Search</button>
            </form>
         </div>
        <!-- mobile menu section start here =========================== -->
        <div class="mobile" id="menuBack" onclick="hideMobileMenuHandler()">
          <div class="menu" id="menu">
            <a href="index.php">Home</a>
            <a href="#">Browse</a>
            <a href="index.php#browseAll">Browse All</a>
              <a href="login.php">My Account</a>
              <a href="appointment.php">Appointments</a>
              <a href="servicess.php">Services</a>
          </div>
        </div>
        <!-- mobile menu section end here =========================== -->
  
        <!-- main content section start here, hero section ==================== -->
        <div class="main-section">
          <div class="row">
            <h3>Home</h3>
            <h1>APPOINTMENTS</h1>
          </div>
        </div>
        <!-- main content section end here, hero section ==================== -->
      </div>



     <!-- our team section start here ========================= -->
     <div class="our_team">
     <div class="appointmentForm" id="appointment">
            <div class="inner">
               <span onclick="hideAppointHandler()">x</span>
               <h1>Book An Appointment</h1>
               <form name="reservation" action="reservation.php" onsubmit = "return validation()" method="POST" enctype="multipart/form-data">
               <input type="text" value="<?php echo $nom[5]?>" name="nom" readonly>
               <input type="text" value="<?php echo $prenom[5]?>" name="prenom" readonly>
               <input type="text" value="5" name="price" readonly>
               <input type="time" placeholder="Heure" name="heure">
               <input type="date" placeholder="Date" min="2022-05-30" max="2022-12-31" name="date">
               <a>Enter your credit card informations</a>
               <input type="text" placeholder="adresse" name="adresse">
               <input type="text" placeholder="ville" name="ville">
               <input type="number" placeholder="Code Postal" name="postal">
               <input type="text" placeholder="Pays" name="pays">
               <input type="text" placeholder="Type de carte" name="type">
               <input type="text" value="<?php echo $nom1?>" name="nom1" readonly>
               <input type="text" value="<?php echo $prenom1?>" name="prenom1" readonly>
               <input type="text" placeholder="Expiration Date" name="expiration">
               <input type="text" placeholder="Code" name="code">
               <button type="submit" name="confirmer">Confirm</button>
              </form>
            </div>
        </div>
      <div class="our_team_top">
        <h1>Our Team Member</h1>
      </div>
      <div class="row">
      <div href="#" id="bodyB" class="card coach_1" style="background-image: url('assets/<?php echo $image[5] ?>')"> 
          <div class="social_media">
            <!-- <a href="./pages/profile.html">VIEW PROFILE</a> -->
            <div class="show_icons">
               <p><b>Phone :</b> <?php echo $phone[5]?></p>
               <p><b>Email :</b><?php echo $email[5]?></p>
               <p><b>Room :</b>  &nbsp;G-010</p>
               <a href="#">RESUME</a>
               <br>
               <a href="#" onclick="showAppointHandler()">Appointment</a>
               <a onclick="validation()">Chatroom</a>
               <a href="test.html">Dedicace</a>
            </div>
          </div>
          <div class="footer">
            <p><?php echo $activite[5]?></p>
            <h1><?php echo $nom[5]." ".$prenom[5] ?></h1>
          </div>
        </div>
        <div href="#" id="fitness" class="card coach_2" style="background-image: url('assets/<?php echo $image[6] ?>')"> 
          <div class="social_media">
            <!-- <a href="./pages/profile.html">VIEW PROFILE</a> -->
            <div class="show_icons">
               <p><b>Phone :</b> <?php echo $phone[6]?></p>
               <p><b>Email :</b><?php echo $email[6]?></p>
               <p><b>Room :</b>  &nbsp;G-010</p>
               <a href="#">RESUME</a>
               <br>
               <a href="#" onclick="showAppointHandler()">Appointment</a>
               <a onclick="validation()">Chatroom</a>
            </div>
          </div>
          <div class="footer">
            <p><?php echo $activite[6]?></p>
            <h1><?php echo $nom[6]." ".$prenom[6] ?></h1>
          </div>
        </div>
        <div href="#" id="biking"  class="card coach_3" style="background-image: url('assets/<?php echo $image[7] ?>')"> 
          <div class="social_media">
            <!-- <a href="./pages/profile.html">VIEW PROFILE</a> -->
            <div class="show_icons">
               <p><b>Phone :</b> <?php echo $phone[7]?></p>
               <p><b>Email :</b><?php echo $email[7]?></p>
               <p><b>Room :</b>  &nbsp;G-010</p>
               <a href="#">RESUME</a>
               <br>
               <a href="#" onclick="showAppointHandler()">Appointment</a>
               <a onclick="validation()">Chatroom</a>
            </div>
          </div>
          <div class="footer">
            <p><?php echo $activite[7]?></p>
            <h1><?php echo $nom[7]." ".$prenom[7] ?></h1>
          </div>
        </div>
        <div href="#" id="cardio" class="card coach_4" style="background-image: url('assets/<?php echo $image[8] ?>')"> 
          <div class="social_media">
            <!-- <a href="./pages/profile.html">VIEW PROFILE</a> -->
            <div class="show_icons">
               <p><b>Phone :</b> <?php echo $phone[8]?></p>
               <p><b>Email :</b><?php echo $email[8]?></p>
               <p><b>Room :</b>  &nbsp;G-010</p>
               <a href="#">RESUME</a>
               <br>
               <a href="#" onclick="showAppointHandler()">Appointment</a>
               <a onclick="validation()">Chatroom</a>
            </div>
          </div>
          <div class="footer">
            <p><?php echo $activite[8]?></p>
            <h1><?php echo $nom[8]." ".$prenom[8] ?></h1>
          </div>
        </div>
        <div href="#" id="group" class="card coach_5" style="background-image: url('assets/<?php echo $image[9] ?>')"> 
          <div class="social_media">
            <!-- <a href="./pages/profile.html">VIEW PROFILE</a> -->
            <div class="show_icons">
               <p><b>Phone :</b> <?php echo $phone[9]?></p>
               <p><b>Email :</b><?php echo $email[9]?></p>
               <p><b>Room :</b>  &nbsp;G-010</p>
               <a href="#">RESUME</a>
               <br>
               <a href="#" onclick="showAppointHandler()">Appointment</a>
               <a onclick="validation()">Chatroom</a>
            </div>
          </div>
          <div class="footer">
            <p><?php echo $activite[9]?></p>
            <h1><?php echo $nom[9]." ".$prenom[9] ?></h1>
          </div>
        </div>
      </div>
     
    </div>
   
  </div>
  <script>  
          function validation()  
          {  
              var nom=document.reservation.nom.value;  
              var pays=document.reservation.pays.value;  
              var prenom=document.reservation.prenom.value;
              var price=document.reservation.price.value;  
              var heure=document.reservation.heure.value;  
              var date=document.reservation.date.value;  
              var adresse=document.reservation.adresse.value;  
              var ville=document.reservation.ville.value;  
              var postal=document.reservation.postal.value;  
              var type=document.reservation.type.value;  
              var nom1=document.reservation.nom1.value;  
              var prenom1=document.reservation.prenom1.value;  
              var expiration=document.reservation.expiration.value;  
              var code=document.reservation.code.value;    
              if(nom.length=="" && prenom.length==""&& pays.length==""&& price.length==""&& heure.length==""&& date.length==""&& adresse.length==""&& ville.length==""&& postal.length==""&& type.length==""&& nom1.length==""&& prenom1.length==""&& expiration.length==""&& code.length=="") {  
                  alert("Fields are empty");  
                  return false;  
              }  
              else  
              {  
                  if(nom.length=="") {  
                      alert("nom is empty");  
                      return false;  
                  }  
                  if(pays.length=="") {  
                      alert("Pays is empty");  
                      return false;  
                  }  
                  if (prenom.length=="") {  
                  alert("prenom field is empty");  
                  return false;  
                  }
                  if(price.length=="") {  
                      alert("price is empty");  
                      return false;  
                  } 
                  if(heure.length=="") {  
                      alert("heure is empty");  
                      return false;  
                  } 
                  if(date.length=="") {  
                      alert("date is empty");  
                      return false;  
                  } 
                  if(adresse.length=="") {  
                      alert("adresse is empty");  
                      return false;  
                  } 
                  if(ville.length=="") {  
                      alert("ville is empty");  
                      return false;  
                  } 
                  if(postal.length=="") {  
                      alert("postal is empty");  
                      return false;  
                  } 
                  if(type.length=="") {  
                      alert("type is empty");  
                      return false;  
                  } 
                  if(nom1.length=="") {  
                      alert("nom1 is empty");  
                      return false;  
                  } 
                  if(prenom1.length=="") {  
                      alert("prenom1 is empty");  
                      return false;  
                  } 
                  if(expiration.length=="") {  
                      alert("expiration is empty");  
                      return false;  
                  }
                  if(code.length=="") {  
                      alert("code is empty");  
                      return false;  
                  } 

              }                             
          }  
</script>
 <script src="js/app.js"></script>
</body>
</html>