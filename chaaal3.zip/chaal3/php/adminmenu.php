<?php
session_start();
$nom=$_SESSION['Nom'];
$prenom=$_SESSION['Prenom'];

?>
<html>
    <p>ADMIN MENU <?php echo htmlspecialchars($nom);echo " ";echo htmlspecialchars($prenom) ?><p>
    <a href="ajouterCoach.php"><button type="button" name="addCoach">Ajouter un coach</button></a>
    <a href="suppCoach.php"><button type="button" name="SupprimerCoach">Supprimer un coach</button></a>
    <a href="suppClient.php"><button type="button" name="SupprimerClient">Supprimer un client</button></a>


</html>
