<?php 
$nom = isset($_POST["nom"])? $_POST["nom"] : "";
$prenom = isset($_POST["prenom"])? $_POST["prenom"] : "";
$ecole = isset($_POST["ecole"])? $_POST["ecole"] : "";
$email = isset($_POST["email"])? $_POST["email"] : "";
$mdp = isset($_POST["mdp"])? $_POST["mdp"] : "";

$uniqid=uniqid();
$uniqid2=uniqid();		
// If upload button is clicked ...
if (isset($_POST['create'])) {

	$db = mysqli_connect("localhost", "root", "", "omnes");

		// Get all the submitted data from the form
		$sql = "INSERT INTO client(ID_Client,Nom, Prenom, Email, MDP, ID_CE) VALUES ('$uniqid','$nom', '$prenom', '$email', '$mdp','$uniqid2')";
		// Execute query
		mysqli_query($db, $sql);	

		$sql = "INSERT INTO carteetudiante(ID_CE,Nom, Prenom, Ecole) VALUES ('$uniqid2','$nom', '$prenom', '$ecole')";
		// Execute query
		mysqli_query($db, $sql);	
		header("location: ../pages/login.html");
	}
	

?>

