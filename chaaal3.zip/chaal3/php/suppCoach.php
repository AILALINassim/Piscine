<?php
$con=mysqli_connect("localhost", "root", "", "omnes");

$s1="SELECT * from coach";
$result1 = mysqli_query($con, $s1);

    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>"."ID_Coach"."</th>";
    echo "<th>"."Nom"."</th>";
    echo "<th>"."Prenom"."</th>";
    echo "<th>"."Activite"."</th>";
    echo "<th>"."Phone"."</th>";
    echo "<th>"."Email"."</th>";
    echo "<th>"."Password"."</th>";
    while ($row1 = mysqli_fetch_array($result1)) {
        echo "<tr>";
        echo "<td>".$row1["ID_Coach"]."</td>";
        echo "<td>".$row1["Nom"]."</td>";
        echo "<td>".$row1["Prenom"]."</td>";
        echo "<td>".$row1["Activite"]."</td>";
        echo "<td>".$row1["Phone"]."</td>";
        echo "<td>".$row1["Email"]."</td>";
        echo "<td>".$row1["MDP"]."</td>";
        echo "</tr>";
    }

if (isset($_POST['supprimer'])) {
    $ID_Coach = $_POST['ID_Coach'];
    $d1="DELETE from coach where ID_Coach='$ID_Coach'";    
    $result1 = mysqli_query($con, $d1);
    if(mysqli_query($con,$d1))
        {
            echo '<script>alert("Coach deleted successfully")</script>';
            header("location: suppCoach.php");
        }
}
?>



<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>OMNES Sports</title>
</head>

<body>
<form action="suppCoach.php" method="post" enctype="multipart/form-data">
    <?php
    $con=mysqli_connect("localhost", "root", "", "omnes");

    $s1="SELECT * from coach";
    $result1 = mysqli_query($con, $s1);
        echo "<select name='ID_Coach'>";
        while ($row1 = mysqli_fetch_array($result1)) {
           echo "<option value='" .$row1['ID_Coach']."'> ".$row1['ID_Coach'] . "</option>"; 
        }
        echo "</select>"
    ?>
    <button type="submit" name="supprimer">Supprimer</button>
    </form>
</body>

</html>

