<?php      
    $con=mysqli_connect("localhost", "root", "", "omnes"); 
 
      
        if(isset($_POST['log'])){
            session_start();
            $email = $_POST['Email'];  
            $mdp = $_POST['Mdp'];  
      
        //to prevent from mysqli injection  
        $email = stripcslashes($email);  
        $mdp = stripcslashes($mdp);  
        $email = mysqli_real_escape_string($con, $email);  
        $mdp = mysqli_real_escape_string($con, $mdp);     
        $sql = "select Nom, Prenom from admin where Email = '$email' and MDP = '$mdp'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){  
            $_SESSION['Nom']=$row["Nom"];
            $_SESSION['Prenom']=$row['Prenom'];
            header("location: adminmenu.php");
        }  
        else{  
            echo "<h1> Login failed. Invalid email or password.</h1>";  
        }    
    } 
?> 


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .login{
            width: 96%;
            max-width: 500px;
            margin:50px;
            padding: 25px 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .login h1{
            text-align: left;
        }
        .login form p{
            margin-top: 15px;
        }
        .login form input{
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            outline: none;
            box-shadow: none;
        }
        .login button{
               padding: 10px 25px;
               border: 2px solid #DA361B;
               border-radius: 5px;
               color: #000;
               cursor: pointer;
               background: transparent;
               margin-left: 375px;
        }
        .login button:hover{
            background-color: #DA361B;
            color: #fff;
        }
    </style>
</head>


<html>
    <div class="login">
        <h1>LOGIN ADMIN</h1>
        <form name="login" action="admin.php" onsubmit = "return validation()" method="POST" enctype="multipart/form-data">
            <p>Email Address</p>
            <input type="text" placeholder="Email" name="Email">
            <p>Password</p>
            <input type="password" placeholder="Password" name="Mdp">
            <br>
            <br>
            <input type="submit" value="Login" name="log">
        </form>
    </div>


    <script>  
        function validation()  
        {  
            var id=document.login.Email.value;  
            var ps=document.login.Mdp.value;  
            if(id.length=="" && ps.length=="") {  
                alert("Email and Password fields are empty");  
                return false;  
            }  
            else  
            {  
                if(id.length=="") {  
                    alert("Email is empty");  
                    return false;  
                }   
                if (ps.length=="") {  
                alert("Password field is empty");  
                return false;  
                }  
            }                             
        }  
    </script>  
</html>