<?php
$con=mysqli_connect("localhost", "root", "", "omnes");

$s1="SELECT * from client";
$result1 = mysqli_query($con, $s1);

    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>"."ID_Client"."</th>";
    echo "<th>"."Nom"."</th>";
    echo "<th>"."Prenom"."</th>";
    echo "<th>"."Email"."</th>";
    echo "<th>"."MDP"."</th>";
    echo "<th>"."ID_Reservation"."</th>";
    echo "<th>"."ID_CE"."</th>";
    echo "<th>"."ID_CB"."</th>";
    while ($row1 = mysqli_fetch_array($result1)) {
        echo "<tr>";
        echo "<td>".$row1["ID_Client"]."</td>";
        echo "<td>".$row1["Nom"]."</td>";
        echo "<td>".$row1["Prenom"]."</td>";
        echo "<td>".$row1["Email"]."</td>";
        echo "<td>".$row1["MDP"]."</td>";
        echo "<td>".$row1["ID_Reservation"]."</td>";
        echo "<td>".$row1["ID_CE"]."</td>";
        echo "<td>".$row1["ID_CB"]."</td>";
        echo "</tr>";
    }

if (isset($_POST['supprimer'])) {
    $ID_Client = $_POST['ID_Client'];
    $d1="DELETE from client where ID_Client='$ID_Client'";    
    $result1 = mysqli_query($con, $d1);
    if(mysqli_query($con,$d1))
        {
            echo '<script>alert("Client deleted successfully")</script>';
            header("location: suppClient.php");
        }
}
?>



<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>OMNES Sports</title>
</head>

<body>
<form action="suppClient.php" method="post" enctype="multipart/form-data">
    <?php
    $con=mysqli_connect("localhost", "root", "", "omnes");

    $s1="SELECT * from client";
    $result1 = mysqli_query($con, $s1);
        echo "<select name='ID_Client'>";
        while ($row1 = mysqli_fetch_array($result1)) {
           echo "<option value='" .$row1['ID_Client']."'> ".$row1['ID_Client'] . "</option>"; 
        }
        echo "</select>"
    ?>
    <button type="submit" name="supprimer">Supprimer</button>
    </form>
</body>

</html>