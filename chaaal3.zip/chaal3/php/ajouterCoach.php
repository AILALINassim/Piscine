<?php 
$nom = isset($_POST["nom"])? $_POST["nom"] : "";
$prenom = isset($_POST["prenom"])? $_POST["prenom"] : "";
$activite = isset($_POST["activite"])? $_POST["activite"] : "";
$phone = isset($_POST["phone"])? $_POST["phone"] : "";
$email = isset($_POST["email"])? $_POST["email"] : "";
$mdp = isset($_POST["mdp"])? $_POST["mdp"] : "";
$uniqid=uniqid();	
$msg = "";
// If upload button is clicked ...
if (isset($_POST['Ajouter'])) {

	$filename = $_FILES["my_image"]["name"];
	$tempname = $_FILES["my_image"]["tmp_name"];
		$folder = "../assets/".$filename;
	
	$db = mysqli_connect("localhost", "root", "", "omnes");

		// Get all the submitted data from the form
		$sql = "INSERT INTO coach(ID_Coach,Nom, Prenom, Activite, Phone, Email,MDP, image_url, planning_url, CV_url) VALUES ('$uniqid','$nom', '$prenom', '$activite', '$phone', '$email','$mdp', '$filename','','')";

		// Execute query
		mysqli_query($db, $sql);
		
		// Now let's move the uploaded image into the folder: image
		if (move_uploaded_file($tempname, $folder)) {
			header("location: adminmenu.php");
		}else{
			$msg = "Failed to upload image";
	}
	
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>OMNES Sports</title>
</head>

<body>
    <form name="add" action="ajouterCoach.php" method="POST" enctype="multipart/form-data">
        Nom : <br>
        <input type="text" name="nom"><br>
        Prénom : <br>
        <input type="text" name="prenom"><br>
        Activité sportive : <br>
        <input type="text" name="activite"><br>
        Téléphone : <br>
        <input type="tel" name="phone" pattern="[0-9]{10}"><br>
        Email : <br>
        <input type="email" name="email"><br>
        Password : <br>
        <input type="password" name="mdp"><br>
        Image : <br>
        <input type="file" name="my_image"><br>
        <br>
        <button onclick="return validation()" type="submit" name="Ajouter">Ajouter</button>
    </form>

    <script>  
          function validation()  
          {  
              var nom=document.add.nom.value;  
              var prenom=document.add.prenom.value;  
              var activite=document.add.activite.value;  
              var phone=document.add.phone.value;  
              var mail=document.add.email.value; 
              var mdp=document.add.mdp.value 
              if(nom.length=="" && prenom.length=="" && activite.length=="" && phone.length=="" && mail.length=="" && mdp.length=="") {  
                  alert("Fields are empty");  
                  return false;  
              }  
              else  
              {  
                  if(nom.length=="") {  
                      alert("Nom is empty");  
                      return false;  
                  }   
                  if (prenom.length=="") {  
                  alert("Prenom field is empty");  
                  return false;  
                  } 
                  if (activite.length=="") {  
                  alert("Activite field is empty");  
                  return false;  
                  }  
                  if (phone.length=="") {  
                  alert("Phone field is empty");  
                  return false;  
                  }  
                  if (mail.length=="") {  
                  alert("Email field is empty");  
                  return false;  
                  } 
                  if (mdp.length=="") {  
                  alert("Password field is empty");  
                  return false;  
                  }   
              }                             
          }  
      </script>  
</body>

</html>