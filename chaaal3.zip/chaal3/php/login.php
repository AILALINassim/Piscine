<?php      
    $con=mysqli_connect("localhost", "root", "", "omnes"); 
 
      
        if(isset($_POST['log'])){
            session_start();
            $email = $_POST['Email'];  
            $mdp = $_POST['Mdp'];  
      
        //to prevent from mysqli injection  
        $email = stripcslashes($email);  
        $mdp = stripcslashes($mdp);  
        $email = mysqli_real_escape_string($con, $email);  
        $mdp = mysqli_real_escape_string($con, $mdp);     
        $sql = "select Nom, Prenom, ID_Client from client where Email = '$email' and MDP = '$mdp'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){  
            $_SESSION['Nom']=$row["Nom"];
            $_SESSION['Prenom']=$row['Prenom'];
            $_SESSION['ID_Client']=$row['ID_Client'];
            header("location: ../index.php");
        }  
        else{  
            echo "<h1> Login failed. Invalid email or password.</h1>";  
        }    
    } 
?> 