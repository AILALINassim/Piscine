<?php
session_start();
$nom1=$_SESSION['Nom'];
$prenom1=$_SESSION['Prenom'];
$ID_Client1=$_SESSION['ID_Client'];

$nom = isset($_POST["nom"])? $_POST["nom"] : "";
$heure = isset($_POST["heure"])? $_POST["heure"] : "";
$date = isset($_POST["date"])? $_POST["date"] : "";
$price= isset($_POST["price"])? $_POST["price"] : "";
$adresse= isset($_POST["adresse"])? $_POST["adresse"] : "";
$ville= isset($_POST["ville"])? $_POST["ville"] : "";
$postal= isset($_POST["postal"])? $_POST["postal"] : "";
$type= isset($_POST["type"])? $_POST["type"] : "";
$expiration= isset($_POST["expiration"])? $_POST["expiration"] : "";
$code= isset($_POST["code"])? $_POST["code"] : "";
$pays= isset($_POST["pays"])? $_POST["pays"] : "";


$uniqid=uniqid();
$uniqid1=uniqid();	
$uniqid2=uniqid();	
// If upload button is clicked ...
if (isset($_POST['confirmer'])) {

	$db = mysqli_connect("localhost", "root", "", "omnes");

         $sql = "SELECT ID_Coach from coach WHERE nom='$nom'";
		$result1 = mysqli_query($db, $sql);
        while ($row1 = mysqli_fetch_array($result1)) {
        $ID_Coach=$row1['ID_Coach'];
        }
		// Get all the submitted data from the form
		$sql = "INSERT INTO reservation(ID_Reservation,date, heure, prix, ID_Client, ID_Coach) VALUES ('$uniqid','$date', '$heure','$price','$ID_Client1','$ID_Coach')";
		// Execute query
		mysqli_query($db, $sql);

		$sql = "INSERT INTO cartebancaire(ID_CB,adresse, ville, CodePostal, Pays, ID_Paiement) VALUES ('$uniqid1','$adresse', '$ville', '$postal','$pays','$uniqid2')";
		// Execute query
		mysqli_query($db, $sql);

		$sql = "INSERT INTO paiement(ID_Paiement,Nom, dateexpiration, codesecu, type, ID_Reservation) VALUES ('$uniqid2','$nom1', '$date', '$code','$type','$uniqid')";
		// Execute query
		mysqli_query($db, $sql);
        
        $sql = "UPDATE client SET ID_Reservation='$uniqid' WHERE ID_Client='$ID_Client1'";
		// Execute query
		mysqli_query($db, $sql);

		$sql = "UPDATE client SET ID_CB='$uniqid1' WHERE ID_Client='$ID_Client1'";
		// Execute query
		mysqli_query($db, $sql);

		$sql = "UPDATE coach SET ID_Reservation='$uniqid' WHERE ID_Coach='$ID_Coach'";
		// Execute query
		mysqli_query($db, $sql);

		header("location: appointment.php");
	}
?>

